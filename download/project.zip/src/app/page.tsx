'use client'

import { useState, useEffect } from 'react'

export default function Home() {
  const [seconds, setSeconds] = useState(0)
  const [isRunning, setIsRunning] = useState(true)

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1)
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning])

  // Форматирование времени: минуты:секунды
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60)
    const secs = totalSeconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div
      className="min-h-screen w-full relative overflow-hidden"
      style={{
        background: 'linear-gradient(to right, #FF9449, #F65128)'
      }}
    >
      {/* Логотип с координатами из Figma */}
      <img
        src="/logo.png"
        alt="Logo"
        style={{
          position: 'absolute',
          left: '130px',
          top: '0px',
          width: '352px',
          height: '132px'
        }}
      />

      {/* Изображение sbornik с анимацией при наведении */}
      <img
        src="/sbornik.png"
        alt="Sbornik"
        className="hover-image"
        style={{
          position: 'absolute',
          left: '130px',
          bottom: '50px',
          width: '354.6px',
          height: '476.58px',
          cursor: 'pointer',
          transition: 'transform 0.3s ease, filter 0.3s ease'
        }}
      />

      {/* Таймер - вверху sbornik.png, по центру */}
      <div
        className="timer-container"
        style={{
          position: 'absolute',
          left: '182px',
          bottom: '470px',
          width: '250.93px',
          height: '82.65px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          transition: 'transform 0.3s ease, filter 0.3s ease'
        }}
      >
        <img
          src="/time.png"
          alt="Timer"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain'
          }}
        />
        {/* Текст таймера поверх изображения */}
        <div
          style={{
            position: 'absolute',
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            gap: '10px',
            bottom: '25px'
          }}
        >
          <span
            style={{
              fontSize: '22px',
              fontWeight: 'bold',
              color: 'white',
              textShadow: '0 2px 4px rgba(0,0,0,0.5)',
              letterSpacing: '2px'
            }}
          >
            ТАЙМЕР
          </span>
          <span
            style={{
              fontSize: '34px',
              fontWeight: 'bold',
              color: 'white',
              textShadow: '0 2px 4px rgba(0,0,0,0.5)'
            }}
          >
            {formatTime(seconds)}
          </span>
        </div>
      </div>

      <style jsx>{`
        .hover-image:hover {
          transform: translateY(-10px) scale(1.02);
          filter: drop-shadow(0 10px 20px rgba(0, 0, 0, 0.3));
        }
        .timer-container:hover {
          transform: scale(1.05);
          filter: drop-shadow(0 8px 16px rgba(0, 0, 0, 0.4));
        }
      `}</style>
    </div>
  )
}
